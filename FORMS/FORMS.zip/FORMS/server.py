from flask import Flask, render_template, request, redirect
app = Flask(__name__) 

@app.route("/")
def form():
    return render_template("index.html")



@app.route("/sub", methods=['POST'] )
def submission():
    if request.method == 'POST':
        name = request.form['name']
        city = request.form['city']
        lang = request.form['language']
        area = request.form['area']
        print "this worked"
        return render_template("submission_form.html", name=name, city = city, lang = lang, area=area)
    else:
        print "DEBUG: save() GET method was called"
   

app.run(debug=True)